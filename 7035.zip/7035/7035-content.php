<?php
$url_host = 'http://' . $_SERVER['HTTP_HOST'];
$pattern_document_root = addcslashes(realpath($_SERVER['DOCUMENT_ROOT']), '\\');
$pattern_uri = '/' . $pattern_document_root . '(.*)$/';

preg_match_all($pattern_uri, __DIR__, $matches);
$url_path = $url_host . $matches[1][0];
$url_path = str_replace('\\', '/', $url_path);
?>
<div class="type-7000">
<div class="type-15">
<div class="container">
    <div class="form">
        <form class="form-content">
            <div class="form-header">
                <h3 class="form-title">Do you have any Questions?</h3>
                <p>Fields marked with an <span class="req-symbol">*</span> are required</p>
            </div>
            <!-- form-header -->

            <div class="inline-group row">
                <div class="field required col-sm-4"> <!-- add class error show error -->
                    <label for="name">Name</label>
                    <input type="text" />
                    <div class="error-mes">This is a required field.</div>
                </div>
                <div class="field required col-sm-4"> <!-- add class error show error -->
                    <label for="email">Email</label>
                    <input type="email" />
                    <div class="error-mes">This is a required field.</div>
                </div>

                <div class="field col-sm-4">
                    <label for="phone">Phone</label>
                    <input type="tel" />
                    <div class="error-mes">This is a required field.</div>
                </div>
            </div>

            <div class="field required">
                <label for="message">Message </label>
                <textarea></textarea>
                <div class="error-mes">This is a required field.</div>
            </div>

            <input class="btn-form" type="button" value="Send" />
        </form>
        <!-- end form-content -->
    </div>
    <!-- end form -->
</div>
<!-- end container -->
</div>
</div>
